# Pirate Chest CE — alpha 0.1
Created with love by Kinny. Initial native C adaptation of Pirate Chest Evo v1.0 for TI-84 Plus CE (including non-Python hardware).

## Status
Source project, NOT a compiled calculator program. Portable game engine passed host tests. CE-specific graphics, key input, and AppVar I/O are implemented but not compiled or tested on a calculator yet. The build workflow is provided as an untested convenience. Target OS: 5.0.1.0012; do not update just to run this game. The existing Evo Python save cannot be read on CE; the CE uses PIRCESAV, its own AppVar. Saving occurs every 100 manual openings, after milestones or sales, and at normal exit. Save data is in calculator RAM in this alpha; a RAM reset may erase it.

## Implemented
- Start screen, beach, native GraphX chest, segmented XP bar, lifetime and balance.
- 30 original treasures, unchanged v1.0 rates (each loading screen 1/10272; jam category 11/103910; pickaxes split evenly).
- Exclusive XP rolls: 10 XP = 1/70; 20 XP = 1/140. Each level adds 100 real chest opens, including further XP and loot.
- Collection menu, confirmation before sales, original sale prices; persistent Pirate Shop Access flag and basic golden theme.
- Fresh keypress per manual opening; reward and level-up screens block opening.
- 32-bit rejection sampling; independent draws per pool. Counters saturate at 4,294,967,295.

## Not implemented yet
Cosmetic shop and all 42 skins, full reward illustrations, advanced animations, three selective resets, secret developer menu, Evo save import. Pirate Shop Access is tracked but cannot grant free cosmetics until the shop is ported.

## Build (on a compatible computer)
Install CE C/C++ Toolchain from https://github.com/CE-Programming/toolchain/releases/tag/v15.0 and run `make` from this folder. Expect `bin/PIRATE.8xp`. Install the relevant CE runtime libraries (LibLoad, GRAPHX, KEYPADC, FILEIOC) from https://github.com/CE-Programming/libraries/releases/latest if required by the linked binary. Use the individual .8xv files from the library ZIP if group transfer is unsupported. OS/library compatibility still needs real testing.

## Browser-only build option
The optional `.github/workflows/build.yml` can be placed in a GitHub repository with the rest of these files. In Actions, run the Build Pirate Chest CE workflow; if it succeeds, download the PirateChestCE artifact. No local compiler is required. Do not transfer the C sources to the calculator.

## Running (after a successful native build)
Transfer the compiled PIRATE.8xp and required libraries with a data cable using https://web.tilp.info. On OS 5.0.1, from the home screen enter Asm(prgmPIRATE) via the catalog (2nd, 0) and PRGM menu. ENTER starts and opens; MODE opens/closes loot; UP/DOWN select; ENTER sells in loot after confirmation; CLEAR exits normally. Level screen waits one second, and then requires a fresh ENTER press.

## Host tests
`gcc -std=c11 -Wall -Wextra -Werror -O2 -Isrc src/game.c tests/test.c -o pirate_test && ./pirate_test`
