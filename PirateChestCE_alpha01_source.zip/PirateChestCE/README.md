# Pirate Chest CE 1.0 (full-feature port)
Created with love by Kinny. Native C adaptation of PIRATE1F.py, the final Evo version. Target: TI-84 Plus CE / OS 5.0.1, using CEdev v15.0 and matching CE libraries.

## Update an existing GitHub build
If your existing repository has PirateChestCE_alpha01_source.zip and a workflow that unzips it, upload this ZIP with the same filename in the same directory and commit it. GitHub will run the existing workflow on push. On Actions, open the new run, then Summary > Artifacts > PirateChestCE. Extract PIRATE.8xp and transfer it, replacing your previous PIRATE program. Do not delete the save AppVars. If your existing repo builds directly from source, use the contents of this ZIP's PirateChestCE directory or switch to the ZIP workflow below.

The standalone repository workflow inside the ZIP assumes the source files are in the repo root. The ZIP workflow used in earlier instructions assumes the ZIP is in the repo root. Do not mix them.

## Controls
- ENTER on start screen starts; ENTER in gameplay opens one chest.
- ALPHA opens/closes shop; UP/DOWN chooses; 2nd/DEL or right/left changes pages; ENTER buys/equips.
- MODE opens/closes treasure log; 2nd/DEL changes pages; UP/DOWN selects a treasure; ENTER sells with confirmation. VARS on page 7 opens three independent resets.
- 1987 in gameplay opens developer menu. Previews do not modify progress; developer counters accept up to 4,294,967,295.
- CLEAR exits and saves. Reward screens: DEL or ENTER. Level screen: wait one second, release ENTER, then press ENTER again.

## Port details
23 chest skins and 19 XP skins (including all seven gradients), 30 loot items, original prices/odds, permanent golden theme and free shop upon Pirate Shop Access, 100 bonus openings per level including cascading XP, segmented bar, separate lifetime and spendable counts. Pixel art generated from Evo source, adapted to the CE's 320x240 indexed display. No auto or double-opening upgrades, no RGB/trans chest skins; pride XP skins retained.

## Saves
Previous native CE alpha save PIRCESAV is migrated into PIRCEV1 on first launch. Keep both AppVars. No automatic import of the Evo Python save; the platforms have different formats. Counters use saturating 32-bit integers. Saves occur at milestones, menus, every 100 manual opens and exit. This is not a backup against RAM clearing.

## Verification
Host tests:
```
gcc -std=c11 -Wall -Wextra -Werror -O2 -Isrc src/game.c tests/test.c -o /tmp/test && /tmp/test
gcc -std=c11 -Wall -Wextra -Werror -O2 -Isrc src/game.c tests/shop_test.c -o /tmp/shop && /tmp/shop
gcc -std=c11 -Wall -Wextra -Werror -Itests/stubs -Isrc tests/ui_test.c src/game.c -o /tmp/ui && /tmp/ui
```
UI test uses mock CE APIs and checks draw bounds; it does not validate real GraphX rendering, key timing or hardware save operations. Native compilation and hardware testing still needed. Run make with CEdev installed to produce bin/PIRATE.8xp.
