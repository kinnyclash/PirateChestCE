static inline void delay(unsigned x){(void)x;}
static inline void os_ClrHome(void){}
static inline void os_PutStrFull(const char *s){(void)s;}
