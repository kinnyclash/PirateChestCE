#include <stdint.h>
extern uint8_t kb_Data[8];
static inline void kb_Scan(void){}
#define kb_Clear 64
#define kb_Enter 1
#define kb_Mode 64
#define kb_Del 128
#define kb_2nd 32
#define kb_Alpha 128
#define kb_Vars 64
#define kb_Up 8
#define kb_Down 1
#define kb_Left 2
#define kb_Right 4
#define kb_0 1
#define kb_1 2
#define kb_2 2
#define kb_3 2
#define kb_4 4
#define kb_5 4
#define kb_6 4
#define kb_7 8
#define kb_8 8
#define kb_9 8
