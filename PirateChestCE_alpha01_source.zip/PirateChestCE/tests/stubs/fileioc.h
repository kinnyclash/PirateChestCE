#include <stdint.h>
#include <stddef.h>
static inline uint8_t ti_Open(const char*n,const char*m){(void)n;(void)m;return 0;}
static inline size_t ti_Read(void *p,size_t s,size_t n,uint8_t h){(void)p;(void)s;(void)n;(void)h;return 0;}
static inline size_t ti_Write(const void*p,size_t s,size_t n,uint8_t h){(void)p;(void)s;(void)n;(void)h;return 0;}
static inline void ti_Close(uint8_t h){(void)h;}
