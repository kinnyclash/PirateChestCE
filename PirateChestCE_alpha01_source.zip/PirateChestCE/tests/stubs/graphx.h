#ifndef MOCK_GFX
#define MOCK_GFX
#include <stdint.h>
#include <assert.h>
#include <string.h>
extern uint16_t gfx_palette[256];
extern unsigned test_scale;
static inline void gfx_Begin(void){}
static inline void gfx_End(void){}
static inline void gfx_SetDrawBuffer(void){}
static inline void gfx_SetDrawScreen(void){}
static inline void gfx_FillScreen(uint8_t c){(void)c;}
static inline void gfx_SetColor(uint8_t c){(void)c;}
static inline void gfx_FillRectangle(int x,int y,int w,int h){assert(x>=0&&y>=0&&w>0&&h>0&&x+w<=320&&y+h<=240);}
static inline void gfx_SetTextFGColor(uint8_t c){(void)c;}
static inline void gfx_SetTextBGColor(uint8_t c){(void)c;}
static inline void gfx_SetTextTransparentColor(uint8_t c){(void)c;}
static inline void gfx_SetTextScale(unsigned x,unsigned y){assert(x==y);test_scale=x;}
static inline int gfx_GetStringWidth(const char *s){return (int)strlen(s)*8*test_scale;}
static inline void gfx_PrintStringXY(const char*s,int x,int y){assert(x>=0&&y>=0&&x+gfx_GetStringWidth(s)<=320&&y+8*(int)test_scale<=240);}
static inline void gfx_BlitBuffer(void){}
static inline uint16_t gfx_RGBTo1555(unsigned r,unsigned g,unsigned b){return (r>>3)<<10|(g>>3)<<5|(b>>3);}
#endif
