/* Host-only renderer smoke test; mock GraphX uses conservative 8px per glyph. */
#define main calculator_main
#include "../src/main.c"
#undef main
#include <assert.h>
uint16_t gfx_palette[256]; unsigned test_scale=1;uint8_t kb_Data[8];
int main(void){game_init(&g,123);g.lifetime=g.balance=UINT32_MAX;g.xp=UINT32_MAX-5;for(unsigned theme=0;theme<2;theme++){g.pirate=theme;palette();for(unsigned i=0;i<25;i++)if(CHEST_MASK&(UINT32_C(1)<<i)){g.skin=i;start();main_screen();update_hud(true);}for(unsigned i=0;i<19;i++){g.xp_skin=i;main_screen();}for(unsigned p=0;p<SHOP_PAGES;p++)for(unsigned s=0;s<shop_len(p);s++)shop_screen(p,s,"");for(unsigned p=0;p<7;p++){unsigned n=p==6?1:loot_len[p];for(unsigned s=0;s<n;s++)loot_screen(p,s,"");}for(unsigned i=0;i<30;i++){g.wins[i]=UINT32_MAX;reward(i,UINT32_MAX,false);reward(i,0,true);}option_screen("RESET OPTIONS",reset_names,0,"Only the selected category resets");}puts("UI draw bounds passed: all chest skins, XP skins, shop/loot pages, reward variants, both themes");}
