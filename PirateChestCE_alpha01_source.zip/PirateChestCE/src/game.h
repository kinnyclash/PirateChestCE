#ifndef PIRATE_GAME_H
#define PIRATE_GAME_H
#include <stdint.h>
#include <stdbool.h>
#define ITEMS 30
#define SAVE_MAGIC UINT32_C(0x50434501)
typedef struct {uint32_t magic, lifetime, balance, xp, rng, wins[ITEMS]; uint8_t pirate;} Game;
typedef struct {uint32_t count[ITEMS], opened, levels;} Result;
extern const char *const names[ITEMS];
extern const uint32_t prices[ITEMS];
void game_init(Game *g,uint32_t seed);
uint32_t uniform(Game *g,uint32_t n);
unsigned roll_xp(Game *g);
uint32_t roll_loot(Game *g);
Result open_chest(Game *g);
bool sell(Game *g,unsigned i);
#endif
