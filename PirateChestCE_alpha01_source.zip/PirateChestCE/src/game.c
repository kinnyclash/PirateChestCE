#include "game.h"
#include <string.h>
const char *const names[ITEMS]={"1995 Shadowless Charizard","Golden Hatsune Miku","Golden Kasane Teto","Pirate Shop Access","Golden Car Decal","Winged Moonberry","2-Handed Golden Pickaxe","1-Handed Golden Pickaxe","Golden Backbling","MEGALOVANIA","Hopes and Dreams","Battle Against a True Hero","ASGORE","Death by Glamour","Bonetrousle","Spider Dance","SAVE the World","sans.","His Theme","Minecraft","Undertale","Deltarune","Celeste","Hollow Knight","Fortnite","Doom","Silksong","Pokemon","Plain White","Gizmo"};
const uint32_t prices[ITEMS]={5000000,1000000,1000000,1000000,10000,10000,500,500,250,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,500,500,500,500,500,500,500,500,500,500,100};
void game_init(Game *g,uint32_t seed){memset(g,0,sizeof *g);g->magic=SAVE_MAGIC;g->rng=seed;}
/* Full-width counter + bijective 32-bit mixer. Unsigned arithmetic wraps by design. */
static uint32_t next(Game *g){uint32_t z=(g->rng+=UINT32_C(0x9e3779b9));z=(z^(z>>16))*UINT32_C(0x21f0aaad);z=(z^(z>>15))*UINT32_C(0x735a2d97);return z^(z>>15);}
uint32_t uniform(Game *g,uint32_t n){if(n<=1)return 0;uint32_t threshold=(uint32_t)(0u-n)%n,r;do{r=next(g);}while(r<threshold);return r%n;}
unsigned roll_xp(Game *g){uint32_t x=uniform(g,140);return x<2?10:x==2?20:0;}
uint32_t roll_loot(Game *g){static const uint32_t den[]={3000000,2562500,2562500,137500,17813,17813,10568,10568,103910,10272,1000};static const uint8_t start[]={0,1,2,3,4,5,6,8,9,19,29}, count[]={1,1,1,1,1,1,2,1,10,10,1}, success[]={1,1,1,1,1,1,1,1,11,10,1};uint32_t hits=0;for(unsigned j=0;j<11;j++)if(uniform(g,den[j])<success[j])hits|=UINT32_C(1)<<(start[j]+uniform(g,count[j]));return hits;}
static uint32_t add(uint32_t a,uint32_t b){return UINT32_MAX-a<b?UINT32_MAX:a+b;}
Result open_chest(Game *g){Result r={0};uint32_t left=1;while(left){left--;g->lifetime=add(g->lifetime,1);g->balance=add(g->balance,1);r.opened++;uint32_t h=roll_loot(g);for(unsigned i=0;i<ITEMS;i++)if(h&(UINT32_C(1)<<i)){g->wins[i]=add(g->wins[i],1);r.count[i]++;if(i==3)g->pirate=1;}uint32_t before=g->xp/100;g->xp=add(g->xp,roll_xp(g));uint32_t gained=g->xp/100-before;r.levels+=gained;left+=100*gained;}return r;}
bool sell(Game *g,unsigned i){if(i>=ITEMS||!g->wins[i])return false;g->wins[i]--;g->balance=add(g->balance,prices[i]);return true;}
