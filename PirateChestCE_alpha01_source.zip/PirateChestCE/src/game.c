#include "game.h"
#include <string.h>
const char *const names[ITEMS]={"1995 Shadowless Charizard","Golden Hatsune Miku","Golden Kasane Teto","Pirate Shop Access","Golden Car Decal","Winged Moonberry","2-Handed Golden Pickaxe","1-Handed Golden Pickaxe","Golden Backbling","MEGALOVANIA","Hopes and Dreams","Battle Against a True Hero","ASGORE","Death by Glamour","Bonetrousle","Spider Dance","SAVE the World","sans.","His Theme","Minecraft","Undertale","Deltarune","Celeste","Hollow Knight","Fortnite","Doom","Silksong","Pokemon","Plain White","Gizmo"};
const uint32_t prices[ITEMS]={5000000,1000000,1000000,1000000,10000,10000,500,500,250,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,500,500,500,500,500,500,500,500,500,500,100};
void game_init(Game *g,uint32_t seed){memset(g,0,sizeof *g);g->magic=SAVE_MAGIC;g->rng=seed;g->owned=g->xp_owned=1;}
/* Full-width counter + bijective 32-bit mixer. Unsigned arithmetic wraps by design. */
static uint32_t next(Game *g){uint32_t z=(g->rng+=UINT32_C(0x9e3779b9));z=(z^(z>>16))*UINT32_C(0x21f0aaad);z=(z^(z>>15))*UINT32_C(0x735a2d97);return z^(z>>15);}
uint32_t uniform(Game *g,uint32_t n){if(n<=1)return 0;uint32_t threshold=(uint32_t)(0u-n)%n,r;do{r=next(g);}while(r<threshold);return r%n;}
unsigned roll_xp(Game *g){uint32_t x=uniform(g,140);return x<2?10:x==2?20:0;}
uint32_t roll_loot(Game *g){static const uint32_t den[]={3000000,2562500,2562500,137500,17813,17813,10568,10568,103910,10272,1000};static const uint8_t start[]={0,1,2,3,4,5,6,8,9,19,29}, count[]={1,1,1,1,1,1,2,1,10,10,1}, success[]={1,1,1,1,1,1,1,1,11,10,1};uint32_t hits=0;for(unsigned j=0;j<11;j++)if(uniform(g,den[j])<success[j])hits|=UINT32_C(1)<<(start[j]+uniform(g,count[j]));return hits;}
static uint32_t add(uint32_t a,uint32_t b){return UINT32_MAX-a<b?UINT32_MAX:a+b;}
Result open_chest(Game *g){Result r={0};uint32_t left=1;while(left){left--;g->lifetime=add(g->lifetime,1);g->balance=add(g->balance,1);r.opened++;uint32_t h=roll_loot(g);for(unsigned i=0;i<ITEMS;i++)if(h&(UINT32_C(1)<<i)){g->wins[i]=add(g->wins[i],1);r.count[i]++;if(i==3)g->pirate=1;}uint32_t before=g->xp/100;g->xp=add(g->xp,roll_xp(g));uint32_t gained=g->xp/100-before;r.levels+=gained;left+=100*gained;}return r;}
bool sell(Game *g,unsigned i){if(i>=ITEMS||!g->wins[i])return false;g->wins[i]--;g->balance=add(g->balance,prices[i]);return true;}

bool game_valid(const Game *g){return g->magic==SAVE_MAGIC&&g->pirate<=1&&g->skin<25&&g->xp_skin<19&&(g->owned&1)&&(g->xp_owned&1)&&!(g->owned&~CHEST_MASK)&&!(g->xp_owned&~XP_MASK)&&(g->owned&(UINT32_C(1)<<g->skin))&&(g->xp_owned&(UINT32_C(1)<<g->xp_skin));}
void game_migrate(Game *g,const OldGame *o){game_init(g,o->rng);g->lifetime=o->lifetime;g->balance=o->balance;g->xp=o->xp;g->pirate=o->pirate;memcpy(g->wins,o->wins,sizeof g->wins);}
bool shop_action(Game *g,bool xp,unsigned i){if(i>=(xp?19:25))return false;uint32_t bit=UINT32_C(1)<<i;if(!(bit&(xp?XP_MASK:CHEST_MASK)))return false;uint32_t *owned=xp?&g->xp_owned:&g->owned;if(!(*owned&bit)){uint32_t price=g->pirate?0:1000;if(g->balance<price)return false;g->balance-=price;*owned|=bit;}if(xp)g->xp_skin=i;else g->skin=i;return true;}
void reset_progress(Game *g,unsigned which){if(which==0)g->lifetime=0;else if(which==1){g->owned=g->xp_owned=1;g->skin=g->xp_skin=g->pirate=0;}else if(which==2)memset(g->wins,0,sizeof g->wins);}
