#include <tice.h>
#include <graphx.h>
#include <keypadc.h>
#include <fileioc.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "game.h"
#define SAVE "PIRCESAV"
enum {NIGHT=1,GOLD,CREAM,SKY,SEA,SAND,PALM,WOOD,TRIM,BLUE,RED,WHITE,DARKSEA};
static Game g;static bool saved=true;static unsigned changes;
static bool save(void){uint8_t h=ti_Open(SAVE,"w");if(!h)return saved=false;bool ok=ti_Write(&g,sizeof g,1,h)==1;ti_Close(h);changes=0;return saved=ok;}
static void load(void){game_init(&g,(uint32_t)time(NULL));uint8_t h=ti_Open(SAVE,"r");if(h){Game tmp;if(ti_Read(&tmp,sizeof tmp,1,h)==1&&tmp.magic==SAVE_MAGIC&&tmp.pirate<=1)g=tmp;ti_Close(h);}}
static void palette(void){gfx_palette[NIGHT]=gfx_RGBTo1555(26,22,32);gfx_palette[GOLD]=gfx_RGBTo1555(255,202,55);gfx_palette[CREAM]=gfx_RGBTo1555(255,239,176);gfx_palette[SKY]=gfx_RGBTo1555(62,104,143);gfx_palette[SEA]=gfx_RGBTo1555(22,82,113);gfx_palette[SAND]=gfx_RGBTo1555(147,111,63);gfx_palette[PALM]=gfx_RGBTo1555(36,87,57);gfx_palette[WOOD]=gfx_RGBTo1555(125,67,34);gfx_palette[TRIM]=gfx_RGBTo1555(215,144,45);gfx_palette[BLUE]=gfx_RGBTo1555(80,190,255);gfx_palette[RED]=gfx_RGBTo1555(218,84,64);gfx_palette[WHITE]=gfx_RGBTo1555(255,255,255);gfx_palette[DARKSEA]=gfx_RGBTo1555(24,51,72);}
static void rect(int x,int y,int w,int h,uint8_t c){gfx_SetColor(c);gfx_FillRectangle(x,y,w,h);}
static void label(int x,int y,const char *s,uint8_t c){gfx_SetTextFGColor(g.pirate?GOLD:c);gfx_SetTextBGColor(NIGHT);gfx_PrintStringXY(s,x,y);}
static void center(int y,const char*s,uint8_t c){label((320-gfx_GetStringWidth(s))/2,y,s,c);}
static void big(int y,const char*s,uint8_t c){gfx_SetTextScale(2,2);center(y,s,c);gfx_SetTextScale(1,1);}
static void bg(void){gfx_FillScreen(g.pirate?WOOD:SKY);gfx_SetColor(GOLD);gfx_FillCircle(251,77,29);rect(0,108,320,65,g.pirate?TRIM:SEA);for(int x=0;x<320;x+=43)rect(x,143,27,2,g.pirate?CREAM:SKY);rect(0,173,320,67,SAND);rect(30,72,8,108,WOOD);gfx_SetColor(g.pirate?GOLD:PALM);gfx_FillTriangle(34,56,4,88,34,75);gfx_FillTriangle(34,56,66,87,34,75);gfx_FillTriangle(34,56,18,42,34,69);gfx_FillTriangle(34,56,60,42,34,69);}
static void chest(void){rect(105,69,110,70,g.pirate?GOLD:WOOD);rect(110,74,100,23,g.pirate?CREAM:TRIM);rect(105,98,110,6,GOLD);rect(119,70,6,69,GOLD);rect(195,70,6,69,GOLD);rect(151,94,18,18,GOLD);rect(158,100,4,8,NIGHT);}
static void footer(const char*s){rect(0,222,320,18,NIGHT);center(227,s,CREAM);}
static void start(void){bg();rect(46,19,228,38,NIGHT);big(25,"PIRATE CHEST",GOLD);center(46,"CE port alpha 0.1",CREAM);chest();rect(75,163,170,38,NIGHT);center(169,"created with love by Kinny",CREAM);center(186,"ENTER: START",GOLD);footer("CLEAR: Exit");gfx_BlitBuffer();}
static void hud(void){char s[42];rect(60,152,200,61,NIGHT);snprintf(s,sizeof s,"Lifetime: %lu",(unsigned long)g.lifetime);center(158,s,CREAM);snprintf(s,sizeof s,"Balance: %lu",(unsigned long)g.balance);center(175,s,CREAM);snprintf(s,sizeof s,"Level %lu",(unsigned long)(1+g.xp/100));center(194,s,GOLD);for(unsigned j=0;j<10;j++)rect(12,190-12*j,12,9,j<(g.xp%100)/10?(g.pirate?GOLD:BLUE):NIGHT);}
static void main_screen(void){bg();rect(60,12,200,25,NIGHT);big(17,"PIRATE CHEST",GOLD);chest();hud();footer("ENTER: Open   MODE: Loot   CLEAR: Exit");gfx_BlitBuffer();}
static void loot(unsigned i,const char*msg){char s[48];gfx_FillScreen(NIGHT);big(12,"TREASURE LOG",GOLD);unsigned first=(i/10)*10;for(unsigned j=first;j<first+10;j++){if(j==i)rect(5,42+15*(j-first),310,13,DARKSEA);label(8,44+15*(j-first),names[j],j==i?GOLD:CREAM);snprintf(s,sizeof s,"%lu",(unsigned long)g.wins[j]);label(312-gfx_GetStringWidth(s),44+15*(j-first),s,CREAM);}snprintf(s,sizeof s,"Sell: %lu | %s",(unsigned long)prices[i],msg);center(201,s,GOLD);footer("UP/DOWN: Select  ENTER: Sell  MODE: Back");gfx_BlitBuffer();}
static void reward(unsigned i,uint32_t amount){char s[38];gfx_FillScreen(NIGHT);big(20,"TREASURE FOUND!",GOLD);chest();center(150,names[i],GOLD);if(i>=9&&i<19)center(163,"Jam track - Toby Fox",CREAM);if(i>=19&&i<29)center(163,"Loading screen",CREAM);snprintf(s,sizeof s,"Collected this opening: %lu",(unsigned long)amount);center(184,s,CREAM);footer("ENTER: Continue");gfx_BlitBuffer();}
static void level(Result*r){char s[48];gfx_FillScreen(NIGHT);for(int x=12;x<310;x+=25){rect(x,25+x%23,4,4,GOLD);rect(x,185-x%23,3,3,BLUE);}big(65,"LEVEL UP!",GOLD);snprintf(s,sizeof s,"Level %lu",(unsigned long)(1+g.xp/100));big(103,s,CREAM);snprintf(s,sizeof s,"%lu bonus chests opened",(unsigned long)(r->opened-1));center(146,s,CREAM);footer("Wait one second...");gfx_BlitBuffer();delay(1000);footer("ENTER: Continue");gfx_BlitBuffer();}
/* Wait for a fresh physical keypress, not a held key. */
static unsigned key(void){kb_Scan();if(kb_Data[6]&kb_Clear)return 5;if(kb_Data[6]&kb_Enter)return 1;if(kb_Data[1]&kb_Mode)return 2;if(kb_Data[7]&kb_Up)return 3;if(kb_Data[7]&kb_Down)return 4;if(kb_Data[1]&kb_Del)return 6;return 0;}
static unsigned wait_key(void){while(key()){}unsigned k;while(!(k=key())){}return k;}
static bool confirm(void){gfx_FillScreen(NIGHT);big(70,"SELL ONE COPY?",GOLD);footer("ENTER: Confirm   DEL: Cancel");gfx_BlitBuffer();return wait_key()==1;}
int main(void){load();gfx_Begin();palette();gfx_SetDrawBuffer();gfx_SetTextTransparentColor(0);gfx_SetTextBGColor(NIGHT);start();unsigned k;bool quit=false;while((k=wait_key())!=1){if(k==5){quit=true;break;}}if(!quit)main_screen();unsigned old=1,selected=0;bool inloot=false;while(!quit){k=key();if(k==old)continue;old=k;if(!k)continue;if(k==5){quit=true;break;}if(k==2){inloot=!inloot;if(inloot)loot(selected,"");else main_screen();continue;}if(inloot){if(k==3)selected=(selected+29)%30;else if(k==4)selected=(selected+1)%30;else if(k==1&&g.wins[selected]){if(confirm()){sell(&g,selected);save();}old=key();}loot(selected,saved?"":"Save failed");continue;}if(k!=1)continue;Result r=open_chest(&g);changes++;bool any=false;for(unsigned i=0;i<ITEMS;i++)if(r.count[i])any=true;if(any||r.levels||changes>=100)save();if(r.levels){level(&r);do{k=wait_key();}while(k!=1&&k!=5);if(k==5){quit=true;break;}}for(unsigned i=0;i<ITEMS;i++)if(r.count[i]){reward(i,r.count[i]);do{k=wait_key();}while(k!=1&&k!=5);if(k==5){quit=true;break;}}if(quit)break;if(any||r.levels)main_screen();else{hud();gfx_BlitBuffer();}old=1;}save();gfx_End();if(!saved){os_ClrHome();os_PutStrFull("Save failed!");}return 0;}
